package com.covidsurvivals.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;

public class ImportCSVToSQL {

    public static void ImportToSQL(){
        Connection conn = null;
        try {
            conn = JdbcSQLServerConnection.ConnectDatabase();
            PreparedStatement statement = conn.prepareStatement("delete from CovidStatesData");
            statement.executeUpdate();

            PreparedStatement pst = conn.prepareStatement("insert into CovidStatesData (Date, StateName, StateId, TotalCases, TotalDeaths) values (?,?,?,?,?)");

            BufferedReader lineReader = new BufferedReader(new FileReader(System.getProperty("user.dir") + "\\us_states.csv"));
            String lineText = null;

            int count = 0;
            int batchSize = 20;
            lineReader.readLine(); // skip header line

            while ((lineText = lineReader.readLine()) != null) {
                String[] data = lineText.split(",");
                Date date = Date.valueOf(data[0]);
                String stateName = data[1];
                int stateId = Integer.parseInt(data[2]);
                long totalCases = Long.parseLong(data[3]);
                long totalDeaths = Long.parseLong(data[4]);

                pst.setDate(1, date);
                pst.setString(2, stateName);
                pst.setInt(3, stateId);
                pst.setLong(4, totalCases);
                pst.setLong(5, totalDeaths);

                pst.addBatch();

                if (count % batchSize == 0) {
                    pst.executeBatch();
                }
            }

            lineReader.close();

            // execute the remaining queries
            pst.executeBatch();

            conn.commit();
            System.out.println("Data successfully inserted...");

        } catch (IOException ex) {
                System.err.println(ex);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
