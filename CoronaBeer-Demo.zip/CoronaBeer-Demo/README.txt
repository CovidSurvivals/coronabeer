This is an assembly kit for your final deployment.

It would be nice to see that you have a deployable product to demo from.

Included in this package is a complete kit for my 'hangman' demo application.

Scripts:
  build -> compiles application code, builds JAR, generates Javadoc
  run   -> runs application

I've provided pairs of scripts for Win and unix (includes macOS).

These scripts are run *outside* the IDE, i.e., at a command prompt.

RECOMMEND creating a staging area for your project *away* from IntelliJ.
  Perhaps C:\StudentWork\demo-stage\hangman
  or even C:\Temp\hangman
  
  Do this on the filesystem, copying select items from your real project into the staging area:
  hangman/src   ->  source tree      [test code and JUnit JARs not needed, this is a product build]
  hangman/lib   ->  third-party library JARs (if any)
  hangman/other ->  other folders used by your code (if any), e.g., a 'config' folder, etc.
  
  Note that it is entirely possible that all you have is:
  hangman/src       perfectly fine if you don't use any external libraries or have any subfolders

The command prompt should be in this staging directory of your project (see above).


Read the comments in both scripts and adjust to your needs.

This is normally done via build tools such as Maven or Gradle, but we're not using those,
and besides, you should see how it's done with the bare metal JDK tools anyway.